local QBCore = exports['qb-core']:GetCoreObject()

-- Setup QB-target for the gumball machine interaction
exports['qb-target']:AddTargetModel({'prop_gumball_01', 'prop_gumball_02', 'prop_gumball_03'}, {
    options = {
        {
            type = "client",
            event = "gumball:client:getGumball",
            icon = "fas fa-candy-cane",
            label = "Buy Gumball ($1)"
        }
    },
    distance = 2.0
})

RegisterNetEvent('gumball:client:getGumball', function()
    print("Client: Attempting to purchase gumball...")  -- Debug message
    TriggerServerEvent('gumball:server:purchaseGumball')
end)

