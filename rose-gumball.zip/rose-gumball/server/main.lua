local QBCore = exports['qb-core']:GetCoreObject()

-- Server event to handle the purchase of a gumball
RegisterNetEvent('gumball:server:purchaseGumball', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    print("Server: Received gumball purchase request from player " .. src)  -- Debug message

    -- Gumball list (available gumballs) should remain here as we need it for random selection
    local gumballs = {
        'gumball_red',
        'gumball_green',
        'gumball_orange',
        'gumball_pink',
        'gumball_blue',
        'gumball_purple',
        'gumball_yellow'
    }

    -- Attempt to remove $1 from the player
    if Player.Functions.RemoveMoney('cash', 1, "Bought a gumball") then
        print("Server: Player has enough cash and $1 has been deducted.")  -- Debug message
        local randomGumball = gumballs[math.random(1, #gumballs)]  -- Get a random gumball

        -- Attempt to add a random gumball to the player's inventory
        if Player.Functions.AddItem(randomGumball, 1) then
            print("Server: Added " .. randomGumball .. " to player's inventory.")  -- Debug message
            TriggerClientEvent('QBCore:Notify', src, "You received a " .. randomGumball:gsub("_", " ") .. "!", 'success')
            TriggerClientEvent("inventory:client:ItemBox", src, QBCore.Shared.Items[randomGumball], "add")
        else
            print("Server: Failed to add item to inventory.")  -- Debug message
            TriggerClientEvent('QBCore:Notify', src, "Failed to add item to inventory.", 'error')
        end
    else
        print("Server: Player does not have enough cash.")  -- Debug message
        TriggerClientEvent('QBCore:Notify', src, "You don't have enough cash!", 'error')
    end
end)

