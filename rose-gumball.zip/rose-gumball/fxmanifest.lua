fx_version 'cerulean'
game 'gta5'

author 'Rosedrip'
description 'Gumball Machine Script for QBcore'
version '1.0.0'

-- Dependencies
dependencies {
    'qb-core',
    'qb-target'
}

-- Client Scripts
client_scripts {
    'client/main.lua'
}

-- Server Scripts
server_scripts {
    '@qb-core/shared/locale.lua',
    'server/main.lua'
}

-- Shared (for accessing items in both server and client scripts if needed)
shared_scripts {
    '@qb-core/shared/items.lua'
}