Simple Gumball Machine Script for QB-core

1. Open the Install folder and add the images to your qb-inventory, lj-inventory or ps-inventory images.
2. Add the items to your qbcore items.lua
3. add the following items to your consumables script that you use.
gumball_blue
gumball_yellow
gumball_red
gumball_purple
gumball_green
gumball_pink
gumball_orange
3. delete install folder when your done, not needed, im just OCD.